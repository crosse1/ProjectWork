package content;

import content.Price.Price;

public class ProductBook {
    private String product;
    private ProductBookSide buyside;
    private ProductBookSide sellside;

    public ProductBook(String product) throws InvalidEntryException {
        if(product == null || !product.matches("[A-Za-z0-9]{1,5}")){
            throw new InvalidEntryException("Failed to make Product Book: " + product);
        }

        else{
        this.product = product;}
        this.buyside = new ProductBookSide(BookSide.BUY);
        this.sellside = new ProductBookSide(BookSide.SELL);
    }

    public TradableDTO add(Tradable t) throws InvalidEntryException, InvalidPriceException {
        if (t==null){
            throw new InvalidEntryException("Added Tradable cannot be null");
        }
        TradableDTO addDto= null;
        if(t.getSide() == BookSide.BUY){
            addDto = buyside.add(t);
        }
        else if(t.getSide() == BookSide.SELL){
            addDto = sellside.add(t);
        }
        if (t.getType().equals("side quote")){
            System.out.println("Quote ADD: " + t.getUser() + " for " + t.getProduct() + ":");
        }
        System.out.println("**ADD: " + t.getUser() + " " + t.getSide() + " " + t.getType() + ": " +
                t.getProduct() + " at " + t.getPrice() +
                ", Orig Vol: " + t.getOriginalVolume() +
                ", Rem Vol: " + t.getRemainingVolume() +
                ", Fill Vol: " + t.getFilledVolume() +
                ", CXL Vol: " + t.getCancelledVolume() +
                ", ID: " + t.getId());

        tryTrade();
        updateMarket();



        return addDto;
    }

    public TradableDTO[] add(Quote qte) throws InvalidEntryException, InvalidPriceException {

        if(qte == null){
            throw new InvalidEntryException("Quote cannot be null");
        }
        System.out.println("Quote ADD: " + qte.getUser() + " for " + qte.getProduct() + ":");
        removeQuotesForUser(qte.getUser());

        TradableDTO buyDTO = buyside.add(qte.getQuoteSide(BookSide.BUY));
        TradableDTO sellDTO = sellside.add(qte.getQuoteSide(BookSide.SELL));

        tryTrade();

        TradableDTO[] tda = new TradableDTO[2];

        tda[0] = buyDTO;
        tda[1] = sellDTO;


        for (TradableDTO t : tda){
            System.out.println("**ADD: " + t.user() + " " + t.side() + " " + t.type() + ": " +
                    t.product() + " at " + t.price() +
                    ", Orig Vol: " + t.originalVolume() +
                    ", Rem Vol: " + t.remainingVolume() +
                    ", Fill Vol: " + t.filledVolume() +
                    ", CXL Vol: " + t.cancelledVolume() +
                    ", ID: " + t.tradableId());
        }
        return tda;
    }

    public TradableDTO cancel(BookSide side, String orderId) throws InvalidEntryException, InvalidPriceException {
        TradableDTO cancelledDTO = null;
        if(orderId == null){
            throw new InvalidEntryException("OrderID cannot be null");
        }
        if(side == BookSide.BUY){

            cancelledDTO = buyside.cancel(orderId);
            updateMarket();
        }
        else if(side == BookSide.SELL){

           cancelledDTO = sellside.cancel(orderId);
           updateMarket();
        }
        else{throw new InvalidEntryException("Must have a proper enum value");}

        if (cancelledDTO == null){
            throw new InvalidEntryException("DTO is null");
        }
        return cancelledDTO;

    }


    public TradableDTO[] removeQuotesForUser(String userName) throws InvalidEntryException, InvalidPriceException {

        if (userName == null){
            throw new InvalidEntryException("username cannot be null");
        }
        TradableDTO remBuysideDTO = buyside.removeQuotesForUser(userName);
        TradableDTO remSellsideDTO = sellside.removeQuotesForUser(userName);

        TradableDTO[] tdaQ = new TradableDTO[2];

        tdaQ[0] = remBuysideDTO;
        tdaQ[1] = remSellsideDTO;
        updateMarket();
        return tdaQ;


    }

    public void tryTrade() throws InvalidPriceException, InvalidEntryException {
        Price topBuy = buyside.topOfBookPrice();
        Price topSell = sellside.topOfBookPrice();

        if (topBuy == null || topSell == null) {
            return;
        } else {
            int totalToTrade = Math.max(buyside.topOfBookVolume(), sellside.topOfBookVolume());

            if (totalToTrade > 0) {
                Price tBuy = buyside.topOfBookPrice();
                Price tSell = sellside.topOfBookPrice();


                while (tBuy != null && tSell != null && !tSell.greaterThan(tBuy)) {


                    int buyVolume = buyside.topOfBookVolume();
                    int sellVolume = sellside.topOfBookVolume();

                    int toTrade = Math.min(buyVolume, sellVolume);
                    if (toTrade <= 0) break;

                    buyside.tradeOut(tBuy, toTrade);

                    sellside.tradeOut(tBuy, toTrade);

                    tBuy = buyside.topOfBookPrice();
                    tSell = sellside.topOfBookPrice();


                }
            }

        }

    }

        @Override
        public String toString() {

            StringBuilder sumString = new StringBuilder();
            sumString.append("Product Book: ").append(product).append("\n");
            //sumString.append("Side: ").append("BUY").append("\n");
            sumString.append(buyside.toString()).append("\n");
            //sumString.append("Side: ").append("SELL").append("\n");
            sumString.append(sellside.toString());
            return sumString.toString();
        }

    public String getTopOfBookString(BookSide side) throws InvalidEntryException {
        if (side == BookSide.BUY)
            return "Top of BUY book: " +
                    (buyside.topOfBookPrice() == null ? "$0.00" : buyside.topOfBookPrice())
                    + " x " + buyside.topOfBookVolume();
        else
            return "Top of SELL book: " +
                    (sellside.topOfBookPrice() == null ? "$0.00" : sellside.topOfBookPrice())
                    + " x " + sellside.topOfBookVolume();
    }
    private void updateMarket() throws InvalidEntryException, InvalidPriceException {
        int topOfSellVol = sellside.topOfBookVolume();
        int topOfBuyVol = buyside.topOfBookVolume();
        Price topOfSellPrice = sellside.topOfBookPrice();
        Price topOfBuyPrice = buyside.topOfBookPrice();

        CurrentMarketTracker.getInstance().updateMarket(product, topOfBuyPrice, topOfBuyVol, topOfSellPrice, topOfSellVol);
    }
    }


