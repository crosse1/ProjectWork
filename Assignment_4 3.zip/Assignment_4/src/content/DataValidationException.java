package content;

public class DataValidationException extends RuntimeException {
    public DataValidationException(String msg) {
        super(msg);
    }
}
