package content;

import content.Price.Price;

public interface Tradable {
    String getId();
    int getRemainingVolume();
    void setCancelledVolume(int newVol);
    int getCancelledVolume();
    TradableDTO makeTradableDTO();
    Price getPrice();
    void setFilledVolume(int newVol);
    int getFilledVolume();
    BookSide getSide() ;
    String getUser();
    String getProduct();
    int getOriginalVolume();
    void setRemainingVolume(int newVol);
    String getType();

}
