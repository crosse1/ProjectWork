package content;

import content.Price.Price;

public class CurrentMarketSide {

    private Price price;
    private int volume;

    public CurrentMarketSide(Price price, int volume) {
        setPrice(price);
        setVolume(volume);
    }

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    @Override
    public String toString() {
        StringBuilder pvString = new StringBuilder();

        if (price == null){
            pvString.append("$0.00").append("x").append("0");
        }
        else {
            pvString.append(price).append("x").append(volume);
        }

        return pvString.toString();
    }
}
