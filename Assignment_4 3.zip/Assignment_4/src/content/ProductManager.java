package content;


import java.util.*;

public class ProductManager {

    private static ProductManager instance;
    private HashMap<String, ProductBook> pCollection;

    private ProductManager(){
        this.pCollection=new HashMap<>();
    }


    public static ProductManager getInstance(){
        if (instance == null){
            instance = new ProductManager();

        }
        return instance;
    }

    void addProduct(String symbol) throws InvalidEntryException {
        if (symbol == null || !symbol.matches("[A-Za-z0-9]{1,5}")){
            throw new DataValidationException("Symbol is incorrect");
        }
        ProductBook productBook = new ProductBook(symbol);
        pCollection.put(symbol, productBook);
    }

    ProductBook getProductBook(String symbol){
        if(pCollection.containsKey(symbol)){
            return pCollection.get(symbol);
        }

        else{
            throw new DataValidationException("Product is null");
        }
    }

    String getRandomProduct(){
        if (pCollection.isEmpty()){
            throw new DataValidationException("ProductBook map is empty");
        }

        List<String> products = new ArrayList<>();

        for (String product : pCollection.keySet()){
            products.add(product);
        }

        if (products.isEmpty()){
            throw new DataValidationException("ProductBook map is empty");
        }

        Random randomP = new Random();
        int randomIndex = randomP.nextInt(products.size());

        return products.get(randomIndex);


    }

    TradableDTO addTradable(Tradable o) throws InvalidPriceException, InvalidEntryException {
        if (o == null) {
            throw new DataValidationException("Tradable cannot be null");
        }

        //pCollection.get(o.getProduct()).add(o);

        TradableDTO newTradable = pCollection.get(o.getProduct()).add(o);


        //UserManager.getInstance().updateTradable(o.getUser(), newTradable);

        return newTradable;
    }



    TradableDTO[] addQuote(Quote q) throws InvalidEntryException, InvalidPriceException {
        if(q == null){
            throw new DataValidationException("Quote passed in is null");
        }

        pCollection.get(q.getProduct()).removeQuotesForUser(q.getUser());

        TradableDTO quoteBuyTradable = ProductManager.getInstance().addTradable(q.getQuoteSide(BookSide.BUY));
        TradableDTO quoteSellTradable = ProductManager.getInstance().addTradable(q.getQuoteSide(BookSide.SELL));

        TradableDTO[] quoteTradables = new TradableDTO[2];

        quoteTradables[0] = quoteBuyTradable;
        quoteTradables[1] = quoteSellTradable;

        return quoteTradables;

    }

    TradableDTO cancel(TradableDTO o) throws InvalidEntryException, InvalidPriceException {

        if(o==null){
            throw new DataValidationException("o cannot be null");
        }

        TradableDTO cancelledDTO = pCollection.get(o.product()).cancel(o.side(), o.tradableId());

        if (cancelledDTO==null){
            System.out.println("Was not able to cancel");

        }
        return cancelledDTO;
    }

    TradableDTO[] cancelQuote(String symbol, String user) throws InvalidEntryException, InvalidPriceException {

        if(symbol == null){
            throw new DataValidationException("Product symbol is null");
        }

        if(user == null){
            throw new DataValidationException("User is null");
        }

       TradableDTO[] quoteDTO = pCollection.get(symbol).removeQuotesForUser(user);
       return quoteDTO;

    }

    @Override
    public String toString() {
        StringBuilder pbString = new StringBuilder();

        for(String product: pCollection.keySet()){
            pbString.append(pCollection.get(product).toString()).append("\n");

        }

        return pbString.toString();
    }
}
