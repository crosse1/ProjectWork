package content.Price;


import content.InvalidPriceException;

import java.util.Objects;

public class Price implements Comparable<Price> {

    private int cents;

    public Price(int cents){

        this.cents=cents;
    }





    public boolean isNegative() {
        return cents < 0;

    }

    public Price add(Price p)  throws InvalidPriceException {
        if (p==null){
            throw new InvalidPriceException("Cannot read field 'cents' because 'p' is null");
        }
        int new_cents = this.cents + p.cents;
        return new Price(new_cents);
    }

    public Price subtract(Price p) throws InvalidPriceException{
        if (p==null){
            throw new InvalidPriceException("Cannot read field 'cents' because 'p' is null");
        }
        int new_cents = this.cents - p.cents;
        return new Price(new_cents);
    }

    public Price multiply(int n) {
        int new_cents = this.cents * n;
        return new Price(new_cents);
    }

    public boolean greaterOrEqual(Price p) throws InvalidPriceException{
        if(p==null){
            throw new InvalidPriceException("Cannot read field 'cents' because 'p' is null");
        }
        return this.cents >= p.cents;
    }

    public boolean lessOrEqual(Price p) throws InvalidPriceException{
        if(p==null){
            throw new InvalidPriceException("Cannot read field 'cents' because 'p' is null");
        }
        return this.cents <= p.cents;
    }

    public boolean greaterThan(Price p) throws InvalidPriceException{
        if(p==null){
            throw new InvalidPriceException("Cannot read field 'cents' because 'p' is null");
        }
        return this.cents > p.cents;
    }

    public boolean lessThan(Price p) throws InvalidPriceException{
        if(p==null){
            throw new InvalidPriceException("Cannot read field 'cents' because 'p' is null");
        }
        return this.cents < p.cents;
    }

    @Override
    public int compareTo(Price p) {
        if (p==null){
            return this.cents;
        }
        return this.cents - p.cents;
    }

    @Override
    public String toString() {

        double dollar = cents/100.00;

        String form = String.format("$%,.2f", dollar);

        return form;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Price price = (Price) o;
        return cents == price.cents;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cents);
    }
}
