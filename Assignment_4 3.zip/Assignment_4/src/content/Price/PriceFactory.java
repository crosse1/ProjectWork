package content.Price;

import content.InvalidPriceException;

import java.util.HashMap;
import java.util.Map;

public abstract class PriceFactory {

    public static Map<Integer, Price> priceMap = new HashMap<>();


    public static Price makePrice(Integer price){
        if (priceMap.containsKey(price)){
            return priceMap.get(price);
        }

        Price p = new Price(price);
        priceMap.put(price, p);

        return p;
    }

    public static Price makePrice(String cents_string) throws InvalidPriceException {
        String str_edit = cents_string.replaceAll("[$,]", "");

        boolean negative = str_edit.startsWith("-");
        if (negative){
            str_edit = str_edit.replace("-", "");
        }

        if (str_edit.startsWith(".")){
            str_edit = "0" + str_edit;
        }

        if (str_edit.endsWith(".")){
            str_edit = str_edit +"00";
        }
        if (str_edit.contains(".")){
            String[] mon = str_edit.split("\\.");
            if (mon[1].length()>2 || mon[1].length() ==1){
                throw new InvalidPriceException("Invalid Money value");
            }
            int dollar = Integer.parseInt(mon[0]);
            int cent = Integer.parseInt(mon[1]);
            int total = dollar*100 + cent;
            if(negative){
                total= total/(-1);
            }
            return new Price(total);
        }
        else{
            int dollar = Integer.parseInt(str_edit);
            int total = dollar*100;
            if(negative){
                total= total/(-1);
            }
            return makePrice(total);

        }



    }

}
