package content;

public class InvalidUserException extends Exception {
    public InvalidUserException(String message) {
        super(message);
    }
}
