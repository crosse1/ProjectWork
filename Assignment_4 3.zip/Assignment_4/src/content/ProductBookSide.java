package content;

import content.Price.Price;

import java.util.Collections;
import java.util.TreeMap;
import java.util.ArrayList;

public class ProductBookSide {

    private BookSide side;
    private final TreeMap<Price, ArrayList<Tradable>> bookEntries;

    public ProductBookSide(BookSide side) {
        this.side = side;
        if (side == BookSide.BUY) {
            bookEntries = new TreeMap<Price, ArrayList<Tradable>>(Collections.reverseOrder());
        }
        else{
            bookEntries = new TreeMap<Price, ArrayList<Tradable>>();
        }

    }

    public TradableDTO add(Tradable o) throws InvalidEntryException {
        Price p = o.getPrice();

        boolean isPrice = bookEntries.containsKey(p);

        if (!isPrice){
            ArrayList<Tradable> priceTradable = new ArrayList<>();
            bookEntries.put(p, priceTradable);
        }

        bookEntries.get(p).add(o);

        TradableDTO dto = new TradableDTO(o);
        UserManager.getInstance().updateTradable(o.getUser(), dto);

        return dto;
    }

    public TradableDTO cancel(String tradableId) throws InvalidEntryException {

        for (Price p : bookEntries.keySet() ){
            ArrayList<Tradable> tradablesAtPrice = bookEntries.get(p);
            for (int i =0; i < tradablesAtPrice.size(); i++){
                Tradable t = tradablesAtPrice.get(i);

                if(t.getId().equals(tradableId)){

                    System.out.println("**CANCEL: " + t.getUser() + " " + t.getSide() + ": " +
                           t.getId() + " Cxl Qty: " + t.getRemainingVolume());
                    t.setCancelledVolume(t.getCancelledVolume() + t.getRemainingVolume());
                    t.setRemainingVolume(0);
                    tradablesAtPrice.remove(i);

                    if(bookEntries.get(p).isEmpty()){
                        bookEntries.remove(p);
                    }

                    TradableDTO dto = new TradableDTO(t);
                    UserManager.getInstance().updateTradable(t.getUser(), dto);

                    return dto;
                }
            }
        }
        return null;
    }
    public TradableDTO removeQuotesForUser(String userName) throws InvalidEntryException {


        for (Price p : bookEntries.keySet() ){
            ArrayList<Tradable> tradablesAtPrice = bookEntries.get(p);
            for (int i =0; i < tradablesAtPrice.size(); i++){
                Tradable t = tradablesAtPrice.get(i);

                if(t.getUser().equals(userName)){
                    TradableDTO cancelledQuoteDTO = cancel(t.getId());


                    if(tradablesAtPrice.isEmpty()){
                        bookEntries.remove(p);

                    }
                    TradableDTO dto = new TradableDTO(t);
                    UserManager.getInstance().updateTradable(t.getUser(), dto);
                    return cancelledQuoteDTO;
                }

            }
        }
        return null;
    }

    public Price topOfBookPrice(){
        if (bookEntries.isEmpty()){
            return null;
        }
        else{
            return bookEntries.firstKey();
        }
    }

    public int topOfBookVolume() throws InvalidEntryException {



        if (bookEntries.isEmpty()){
            return 0;
        }
        Price p = bookEntries.firstKey();
        ArrayList<Tradable> TopTs = bookEntries.get(p);
        int count = 0;

        for (Tradable t : TopTs){

            count += t.getRemainingVolume();
        }
        return count;
    }



    public void tradeOut(Price price, int volToTrade) throws InvalidPriceException, InvalidEntryException {
        Price p = bookEntries.firstKey();

        if (p == null){
            throw new InvalidEntryException("Price cannot be null");
        }
        else if(p.greaterThan(price)){
            return;


        }
        else{
            ArrayList<Tradable> topArray = bookEntries.get(p);
            int totalVolAtPrice = topOfBookVolume();

            if(volToTrade >= totalVolAtPrice){
                for (Tradable t : topArray){
                    int rv = t.getRemainingVolume();
                    t.setFilledVolume(t.getOriginalVolume());
                    t.setRemainingVolume(0);
                    System.out.println("FULL FILL: (" + t.getSide() + " " + t.getOriginalVolume() + ") "
                            + t.getUser()+ " " + t.getSide() + " order: " + t.getProduct() + " at " + t.getPrice() + ", Orig Vol: "
                            + t.getOriginalVolume() + ", Rem Vol: 0, Fill Vol: " + t.getOriginalVolume()
                            + ", CXL Vol: " + t.getCancelledVolume() + ", ID: " + t.getId());

                    UserManager.getInstance().updateTradable(t.getUser(), new TradableDTO(t));

                }
                bookEntries.remove(p);
                //UserManager.getInstance().updateTradable(t.getUser(), tradableDTO);

            }

            else{
                int remainder = volToTrade;

                for(Tradable t: topArray){
                    if(remainder <= 0){
                        break;
                    }
                    int remainingVol = t.getRemainingVolume();

                    double ratio = (double) remainingVol / totalVolAtPrice;

                  int toTrade = (int)Math.ceil(volToTrade * ratio);

                  toTrade = Math.min(toTrade, remainder);
                  t.setFilledVolume(t.getFilledVolume()+toTrade);
                  t.setRemainingVolume(t.getRemainingVolume() - toTrade);

                    System.out.println("PARTIAL FILL: (" + t.getSide() + " " + toTrade + ") "
                            + t.getUser() + " " + t.getSide() + " order: " + t.getProduct() + " at " + t.getPrice() + ", Orig Vol: "
                            + t.getOriginalVolume() + ", Rem Vol: " + t.getRemainingVolume()
                            + ", Fill Vol: " + t.getFilledVolume() + ", CXL Vol: " + t.getCancelledVolume()
                            + ", ID: " + t.getId());


                    remainder = remainder - toTrade;

                    UserManager.getInstance().updateTradable(t.getUser(),new TradableDTO(t));







                }

                return;
            }




        }


    }
    @Override
    public String toString() {

        StringBuilder sumString = new StringBuilder();
        sumString.append("Side: ").append(side).append("\n");

        if (bookEntries.isEmpty()) {
            sumString.append("\t<Empty>").append("\n");
        } else {
            for (Price p : bookEntries.keySet()) {
                ArrayList<Tradable> tradables = bookEntries.get(p);

                sumString.append("\t").append(p).append(":\n");

                for (Tradable t : tradables) {

                    sumString.append(t.getUser()).append(" ").append(side).append(" ").append(t.getType())
                            .append(": ").append(t.getProduct())
                            .append(" at ").append(t.getPrice()).append(", Orig Vol: ")
                            .append(t.getOriginalVolume()).append(", Rem Vol: ")
                            .append(t.getRemainingVolume()).append(", Fill Vol: ")
                            .append(t.getFilledVolume()).append(", CXL Vol: ")
                            .append(t.getCancelledVolume()).append(", ID: ")
                            .append(t.getId()).append("\n");

                }
            }
        }
            return sumString.toString();

    }


}
