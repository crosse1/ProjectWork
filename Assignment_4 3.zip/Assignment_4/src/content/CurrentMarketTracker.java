package content;

import content.Price.Price;

import java.sql.SQLOutput;

public class CurrentMarketTracker {

    private static CurrentMarketTracker instance;


    public static CurrentMarketTracker getInstance(){
        if (instance == null){
            instance = new CurrentMarketTracker();

        }
        return instance;
    }

    public void updateMarket(String symbol, Price buyPrice, int buyVolume, Price sellPrice, int sellVolume) throws InvalidPriceException {
         Price marketWidth = new Price(0);

         if (sellPrice==null || buyPrice==null){
             marketWidth = new Price(0);


         }
         else{
             marketWidth = sellPrice.subtract(buyPrice);
         }

         CurrentMarketSide buy = new CurrentMarketSide(buyPrice, buyVolume);
         CurrentMarketSide sell = new CurrentMarketSide(sellPrice, sellVolume);
        StringBuilder curMark = new StringBuilder();
        curMark.append("* ").append(symbol).append("   ").append(buy.toString()).
                append(" - ").append(sell.toString()).append(" [")
                        .append(marketWidth).append("]");
        System.out.println("*********** Current Market ***********");
        System.out.println(curMark);
        System.out.println("**************************************");

        CurrentMarketPublisher.getInstance().acceptCurrentMarket(symbol, buy, sell);


    }
}
