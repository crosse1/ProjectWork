package content;

import java.util.HashMap;
import java.util.TreeMap;

public final class UserManager {

    private static UserManager instance;

    private TreeMap<String, User> userTree;

    private UserManager(){
        this.userTree=new TreeMap<>();
    }


    public static UserManager getInstance(){
        if (instance == null){
            instance = new UserManager();

        }
        return instance;
    }

    void init(String[] usersIn) throws InvalidEntryException {
        if (usersIn == null){
            throw new DataValidationException("List passed in is Null");
        }
        for(String u: usersIn){
            User user = new User(u);
            userTree.put(u, user);
        }


    }

    void updateTradable(String userId, TradableDTO o) throws InvalidEntryException {
        if(userId == null){
            throw new DataValidationException("userId cannot be null");
        }
        if(o == null){
            throw new DataValidationException("TradableDTO is null");

        }
        if(!userTree.containsKey(userId)){
            throw new DataValidationException("user does not exist");
        }

        userTree.get(userId).updateTradable(o);


    }

    @Override
    public String toString() {
        StringBuilder userString = new StringBuilder();

        for(String user: userTree.keySet()){

            userString.append(userTree.get(user).toString()).append("\n");

        }

        return userString.toString();
    }

    public User getUser(String userId) throws InvalidUserException {
        if (!userTree.containsKey(userId)){
            throw new InvalidUserException("User does not exist");
        }
        return userTree.get(userId);
    }
}
