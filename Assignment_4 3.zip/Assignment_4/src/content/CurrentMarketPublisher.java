package content;

import java.util.ArrayList;
import java.util.HashMap;

public class CurrentMarketPublisher {

    private static CurrentMarketPublisher instance;
    private HashMap<String, ArrayList<CurrentMarketObserver>> filters;

    private CurrentMarketPublisher(){
            this.filters = new HashMap<>();

    }


    public static CurrentMarketPublisher getInstance(){
        if (instance == null){
            instance = new CurrentMarketPublisher();

        }
        return instance;
    }

    public void subscribeCurrentMarket(String symbol, CurrentMarketObserver cmo){

        if(!filters.containsKey(symbol)){
            filters.put(symbol, new ArrayList<>());
        }
        filters.get(symbol).add(cmo);
    }

    public void unSubscribeCurrentMarket(String symbol, CurrentMarketObserver cmo){
        if(filters.containsKey(symbol)){
            filters.get(symbol).remove(cmo);
        }
        else{
            return;
        }
    }

    public void acceptCurrentMarket(String symbol, CurrentMarketSide buySide, CurrentMarketSide sellSide){
        if(!filters.containsKey(symbol)){
            return;
        }

        else{
            ArrayList<CurrentMarketObserver> cmos = filters.get(symbol);
            for(CurrentMarketObserver cmo: cmos){
                cmo.updateCurrentMarket(symbol, buySide, sellSide);
            }
        }
    }
}
