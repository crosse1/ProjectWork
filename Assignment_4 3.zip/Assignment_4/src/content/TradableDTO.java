package content;

import content.Price.Price;

public record TradableDTO(Tradable tradable, String user, String product,
                          Price price, int originalVolume, int remainingVolume,
                          int cancelledVolume, int filledVolume,
                          BookSide side, String tradableId, String type) {

    public TradableDTO(Tradable tradable) {
        this(tradable, tradable.getUser(), tradable.getProduct(), tradable.getPrice(), tradable.getOriginalVolume(),
                tradable.getRemainingVolume(), tradable.getCancelledVolume(), tradable.getFilledVolume(),
                tradable.getSide(), tradable.getId(), tradable.getType());
    }


}
