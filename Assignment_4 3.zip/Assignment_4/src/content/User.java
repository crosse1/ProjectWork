package content;

import java.util.ArrayList;
import java.util.HashMap;

public class User implements CurrentMarketObserver{

    private String userId;
    private HashMap<String, TradableDTO> tradables;
    private HashMap<String, CurrentMarketSide[]> currentMarkets;

    public User(String userId) throws InvalidEntryException {
        setUserId(userId);
        tradables = new HashMap<>();
        currentMarkets = new HashMap<>();
    }

    public String getUserId() {
        return userId;
    }

    private void setUserId(String userId) throws InvalidEntryException {
        if (!userId.matches("[A-Z]{3}")){
            throw new InvalidEntryException("User ID needs to be exactly three alphabetical characters");
        }
        else{
            this.userId = userId;
        }
    }

    public void updateTradable (TradableDTO o) throws InvalidEntryException {
        if (o==null){
            throw new InvalidEntryException("Object cannot be null");
        }

        tradables.put(o.tradableId(), o);


    }

    @Override
    public String toString() {
        StringBuilder userString = new StringBuilder();
        userString.append("User ID: "). append(userId).append("\n");

        for (String key : tradables.keySet()){
            TradableDTO dto = tradables.get(key);
            userString.append("\tProduct: ").append(dto.product())
                    .append(", Price: ").append(dto.price())
                    .append(", OriginalVolume: ").append(dto.originalVolume())
                    .append(", RemainingVolume: ").append(dto.remainingVolume())
                    .append(", CancelledVolume: ").append(dto.cancelledVolume())
                    .append(", FilledVolume: ").append(dto.filledVolume())
                    .append(", User: ").append(userId)
                    .append(", Side: ").append(dto.side())
                    .append(", Id: ").append(dto.tradableId())
                    .append("\n");
        }
        return userString.toString();
    }

    public void updateCurrentMarket(String symbol, CurrentMarketSide buySide, CurrentMarketSide sellSide){
        CurrentMarketSide[] cmsArray = new CurrentMarketSide[2];
        cmsArray[0] = buySide;

        cmsArray[1] = sellSide;


        currentMarkets.put(symbol, cmsArray);

    }

    public String getCurrentMarkets(){
        StringBuilder cmString = new StringBuilder();

        for(String product: currentMarkets.keySet()){
            CurrentMarketSide buySide = currentMarkets.get(product)[0];
            CurrentMarketSide sellSide = currentMarkets.get(product)[1];
            cmString.append(product).append("   ")
                            .append(buySide.toString()).append(" - ")
                            .append(sellSide.toString()).append("\n");


        }

        return cmString.toString();
    }
}
