package content;

    public enum BookSide {
        BUY, SELL;
    }




