package content;

import content.Price.Price;

public class Quote {

    private String user;
    private String product;
    private QuoteSide buyside;
    private QuoteSide sellside;

    public Quote(String symbol, Price buyPrice, int buyVolume, Price sellPrice, int sellVolume, String userName) throws InvalidEntryException {

        setUser(userName);
        setProduct(symbol);
        this.buyside = new QuoteSide(userName, symbol, buyPrice, buyVolume, BookSide.BUY) ;
        this.sellside = new QuoteSide(userName, symbol, sellPrice, sellVolume, BookSide.SELL);
    }

    public QuoteSide getQuoteSide(BookSide sideIn){
        if(sideIn == BookSide.BUY){
            return buyside;
        }
        else {
            return sellside;
        }

    }

    public String getProduct() {
        return product;
    }

    public void setUser(String user) throws InvalidEntryException {
        if (user.matches("[A-Z]{3}")){
            this.user= user;
        }
        else{
            throw new InvalidEntryException("User ID needs to be exactly three alphabetical characters");
        }
    }

    public void setProduct(String product) throws InvalidEntryException {
        if (product.matches("[A-Za-z0-9]{1,5}")) {
            this.product = product;

        } else {
            throw new InvalidEntryException("Product needs to be 1-5 alphanumeric characters ");

        }
    }

    public String getUser() {
        return user;
    }
}
