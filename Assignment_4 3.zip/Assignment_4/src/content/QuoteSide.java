package content;

import content.Price.Price;

public class QuoteSide implements Tradable {
    private String id;
    private String user;
    private String product;
    private Price price;
    private BookSide side;
    private int originalVolume;
    private int remainingVolume;
    private int cancelledVolume;
    private int filledVolume;

    public QuoteSide(String user, String product, Price price,  int originalVolume, BookSide side) throws InvalidEntryException {

        setUser(user);
        setProduct(product);
        setPrice(price);
        setSide(side);
        setOriginalVolume(originalVolume);
        setRemainingVolume(originalVolume);
        setCancelledVolume(0);
        setFilledVolume(0);
        setId(user+product+price+System.nanoTime());



    }

    @Override
    public String getId() {

        return id;
    }

    private void setId(String id) {
        this.id = id;
    }

    @Override
    public String getUser() {
        return user;
    }

    private void setUser(String user) throws InvalidEntryException {
        if (!user.matches("[A-Z]{3}")){
            throw new InvalidEntryException("User ID needs to be exactly three alphabetical characters");
        }
        else{
            this.user = user;
        }
    }

    @Override
    public String getProduct() {
        return product;
    }

    private void setProduct(String product) throws InvalidEntryException {
        if (!product.matches("[A-Za-z0-9]{1,5}")) {
            throw new InvalidEntryException("Product needs to be 1-5 alphanumeric characters ");

        } else {
            this.product=product;

        }
    }

    @Override
    public Price getPrice() {
        return price;
    }

    private void setPrice(Price price) throws InvalidEntryException{
        if (price == null){
            throw new InvalidEntryException("Price object cannot be null");
        }
        this.price = price;
    }

    @Override
    public BookSide getSide() {
        return side;
    }

    private void setSide(BookSide side) throws InvalidEntryException {
        if (side == null || (side!=BookSide.BUY && side!=BookSide.SELL)){
            throw new InvalidEntryException("Invalid bookside value");
        }
        else {
            this.side=side;
        }
    }

    @Override
    public int getOriginalVolume() {
        return originalVolume;
    }

    private void setOriginalVolume(int originalVolume) throws InvalidEntryException {
        if (originalVolume < 0 && originalVolume > 10000) {
            throw new InvalidEntryException("Order Volume must be greater than 0 and less than 10,000");
        } else {
            this.originalVolume = originalVolume;
        }
    }

    @Override
    public int getRemainingVolume() {
        return remainingVolume;
    }

    public void setRemainingVolume(int remainingVolume) {
        this.remainingVolume = remainingVolume;
    }

    @Override
    public int getCancelledVolume() {
        return cancelledVolume;
    }

    @Override
    public void setCancelledVolume(int cancelledVolume) {
        this.cancelledVolume = cancelledVolume;
    }

    @Override
    public int getFilledVolume() {
        return filledVolume;
    }

    @Override
    public void setFilledVolume(int filledVolume) {
        this.filledVolume = filledVolume;
    }

    @Override
    public String toString() {
        return user + side + "order: " + product + " at " + price + ", Orig Vol: "
                + originalVolume + ", " + filledVolume + ", CXL Vol: " + cancelledVolume
                + ", id:" + id;
    }

    public TradableDTO makeTradableDTO(){
        return new TradableDTO(this, this.getUser(), this.getProduct(), this.getPrice(), this.getOriginalVolume(),
                this.getRemainingVolume(), this.getCancelledVolume(), this.getFilledVolume(),
                this.getSide(), this.getId() , this.getType());
    }

    public String getType(){
        return "side quote";
    }

}
